// routes/items.js
const express = require('express');
const router = express.Router();

// Sample data (in-memory database)
let items = [
  { name: 'Paola', age: 31, occupation: 'RecursosHumanos' },
  { name: 'Alexis', age: 32, occupation: 'IngenieroComputacional' },
  { name: 'Carlos', age: 31, occupation: 'IngenieroElectronico' }
];

// List all items
router.get('/', (req, res) => {
  res.render('index', { items });
});

// Add a new item
router.get('/add', (req, res) => {
  res.render('add');
});

router.post('/add', (req, res) => {
  const newItem = {
    name: req.body.name,
    age: req.body.age,
    occupation: req.body.occupation,
  };

  items.push(newItem);
  res.redirect('/items');
});

// Edit an item
router.get('/edit/:id', (req, res) => {
  const id = req.params.id;
  const item = items[id];
  res.render('edit', { id, item });
});

router.post('/edit/:id', (req, res) => {
  const id = req.params.id;
  const updatedItem = {
    name: req.body.name,
    age: req.body.age,
    occupation: req.body.occupation,
  };

  items[id] = updatedItem;
  res.redirect('/items');
});

// Delete an item
router.get('/delete/:id', (req, res) => {
  const id = req.params.id;
  items.splice(id, 1);
  res.redirect('/items');
});

module.exports = router;
